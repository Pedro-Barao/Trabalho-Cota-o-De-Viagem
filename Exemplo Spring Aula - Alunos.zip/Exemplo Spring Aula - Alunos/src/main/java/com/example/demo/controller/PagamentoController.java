package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.PagamentoDTO;
import com.example.demo.service.PagamentoService;
import com.example.demo.service.Utils.ApiResponse;
import com.example.demo.service.Utils.ErrorResponse;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@Tag(name = "Pagamento", description = "Endpoints para gerenciamento de pagamentos de cotações")
@RestController
@RequestMapping("/api/pagamentos")
public class PagamentoController {

    @Autowired
    private PagamentoService pagamentoService;

    @Operation(summary = "Lista todos os pagamentos", description = "Retorna uma lista de todos os registros de pagamento")
    @GetMapping
    public ResponseEntity<List<PagamentoDTO>> listarPagamentos() {
        List<PagamentoDTO> pagamentos = pagamentoService.listarTodos();
        return ResponseEntity.ok(pagamentos);
    }

    @Operation(summary = "Obter pagamento por ID", description = "Obtém os detalhes de um pagamento específico pelo ID")
    @GetMapping("/{id}")
    public ResponseEntity<PagamentoDTO> buscarPorId(@PathVariable Long id) {
        Optional<PagamentoDTO> pagamentoDTO = pagamentoService.buscarPorId(id);
        return pagamentoDTO.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @Operation(summary = "Registrar Pagamento", description = "Registra um novo pagamento no sistema vinculado a uma cotação")
    @PostMapping
    public ResponseEntity<ApiResponse<PagamentoDTO>> registrarPagamento(@Valid @RequestBody PagamentoDTO pagamentoDTO) {
        try {
            PagamentoDTO savedPagamento = pagamentoService.salvar(pagamentoDTO);
            ApiResponse<PagamentoDTO> response = new ApiResponse<>(savedPagamento);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (IllegalArgumentException e) {
            ErrorResponse errorResponse = new ErrorResponse("Argumento Inválido", e.getMessage());
            return ResponseEntity.badRequest().body(new ApiResponse<>(errorResponse));
        } catch (Exception e) {
            ErrorResponse errorResponse = new ErrorResponse("Erro Interno", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ApiResponse<>(errorResponse));
        }
    }

    @Operation(summary = "Atualizar Status do Pagamento", description = "Atualiza o status de um pagamento (Ex: PENDENTE/PAGO)")
    @PatchMapping("/{id}/status")
    public ResponseEntity<ApiResponse<PagamentoDTO>> atualizarStatus(@PathVariable Long id, @RequestBody String status) {
        try {
            PagamentoDTO atualizado = pagamentoService.atualizarStatus(id, status);
            return ResponseEntity.ok(new ApiResponse<>(atualizado));
        } catch (Exception e) {
            ErrorResponse errorResponse = new ErrorResponse("Erro ao atualizar status", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ApiResponse<>(errorResponse));
        }
    }

    @Operation(summary = "Remover Pagamento", description = "Remove um pagamento do sistema pelo ID")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletarPagamento(@PathVariable Long id) {
        pagamentoService.deletar(id);
        return ResponseEntity.noContent().build();
    }
}